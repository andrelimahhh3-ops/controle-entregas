# Historico de versoes (notas reunidas, ordem alfabetica)


## ATUALIZACAO_V5.10.txt

ÓRBITA v5.10 — PERGUNTAS PREMIUM

ALTERAÇÃO DESTA VERSÃO:
- Somente a área de perguntas do topo foi redesenhada.
- Estilo escolhido: operacional moderno.
- Novo ícone de Prevenção de Perdas: escudo com confirmação.
- Curiosidades usam lâmpada redesenhada.
- Categoria, nível (Fácil/Média/Difícil) e contador aparecem separados.
- Pergunta tem maior destaque e botão "Ver resposta".
- Mantidas as 100 perguntas de Prevenção + 100 Curiosidades.
- Nenhuma regra operacional, histórico ou backup foi alterado.

ATUALIZAÇÃO/CACHE:
- Todos os arquivos usam identificador v5.10.
- Service Worker usa um cache exclusivo da v5.10.
- Ao publicar, confirme que a tela mostra "v5.10".
- Se ainda aparecer v5.9 após substituir os arquivos, faça uma atualização forçada (Ctrl+F5) uma vez.

## ATUALIZACAO_V5.16.txt

ÓRBITA v5.16 — PERFIL CONSULTA / MONITOR

Esta atualização adiciona um perfil de acompanhamento em modo somente leitura.

ACESSO DO PERFIL
- Central Operacional
- Central de Inteligência
- Busca geral
- Relatórios

BLOQUEIOS
- Não cadastra, edita ou exclui entregas.
- Não inicia, edita ou finaliza ciclos.
- Não registra KM, custos, retornos ou conclusão de entrega.
- Não recalcula numeração, recupera registros ou altera metas/configurações.
- Não acessa Cadastros, Lixeira ou Configurações.
- Operação Real fixa para o perfil Monitor.

DADOS
- Nenhum histórico ou backup existente é alterado pela atualização.

IMPORTANTE
- A v5.16 cria o perfil de consulta local. Para enxergar a mesma operação em outro PC/celular em tempo real, ainda será necessária a sincronização online entre dispositivos.

## ATUALIZACAO_V5.17.txt

ÓRBITA v5.17 — ESTABILIDADE DE MEMÓRIA E PROTEÇÃO DE BACKUPS

O que foi corrigido:
- Evita carregar os 50 backups completos na memória apenas para ordenar a lista.
- Evita sobreposição de snapshots automáticos periódicos.
- Agrupa alterações feitas em sequência para evitar filas excessivas de backups completos.
- Usa apenas a lista de identificadores para administrar a retenção dos novos backups.
- A nova retenção só remove backups criados pela rotina segura da v5.17; os backups existentes antes desta atualização são preservados.

Segurança dos dados:
- Mantém o banco IndexedDB `orbita-v2` e a versão do banco existente.
- Não migra, renumera, apaga ou sobrescreve históricos operacionais existentes.
- Não modifica o conteúdo dos backups já gravados.
- A atualização não sincroniza dados entre dispositivos; isso continua dependendo de uma solução online separada.

Atualização recomendada:
1. Não limpe os dados do site no navegador.
2. Faça uma cópia manual do backup JSON, se ainda conseguir abrir as configurações.
3. Publique os arquivos desta versão no mesmo local do GitHub Pages.
4. Abra o site e faça uma recarga forçada (Ctrl+F5) após a publicação.

## ATUALIZACAO_V5.18.txt

ÓRBITA v5.18 — EDIÇÃO E ANULAÇÃO SEGURA DE CUSTOS

O que mudou:
- A tela Custos/Financeiro agora oferece Editar e Anular em cada despesa ativa.
- A edição permite corrigir data, categoria, veículo, entregador, valor e observação.
- A anulação exige motivo, mantém o registro armazenado e retira o valor dos cálculos financeiros e relatórios.
- Os lançamentos anulados ficam consultáveis e podem ser reativados com justificativa.
- Criação, edição, anulação e reativação são registradas pela auditoria já existente.

Proteção dos dados:
- Mantém o banco IndexedDB orbita-v2 e sua versão existente.
- Não apaga nem regrava fisicamente despesas, históricos operacionais ou backups antigos.
- A atualização não publica automaticamente o site: os arquivos precisam ser enviados ao repositório do GitHub Pages.

Publicação recomendada:
1. Antes de atualizar, exporte um backup JSON pelas Configurações se o sistema estiver acessível.
2. Não limpe os dados do site no Chrome.
3. Publique todos os arquivos desta versão no mesmo local do GitHub Pages.
4. Depois da publicação, abra o site e use Ctrl+F5.

## ATUALIZACAO_V5.19.txt

ÓRBITA v5.19 — EDIÇÃO DE VEÍCULO E KM

Na tela Quilometragem, a opção “Editar KM inicial/final” agora permite corrigir: veículo, data do expediente, KM inicial e KM final.

REGRAS DE SEGURANÇA
- Toda correção exige motivo e gera auditoria com dados anteriores e novos.
- Não permite duplicar expediente do mesmo veículo na mesma data.
- Não permite transferir para veículo com ciclo aberto na data.
- Ciclos e entregas ainda vinculados ao expediente acompanham a correção de veículo em uma única transação, evitando atualização parcial.
- Ciclos sem vínculo explícito não são alterados automaticamente.
- A data não pode ser alterada quando há ciclos vinculados ao expediente.
- Nenhum histórico ou backup anterior é apagado ou migrado.

PUBLICAÇÃO
Substitua os arquivos do site pelos arquivos desta atualização, preservando o banco local do navegador. Não limpe os dados do site e não desinstale o aplicativo.

## ATUALIZACAO_V5.20.txt

ÓRBITA v5.20 — EXCLUSÃO SEGURA DE REGISTROS DE QUILOMETRAGEM

O QUE MUDOU
- Na tela Quilometragem, cada expediente ativo agora tem a opção “Excluir registro”.
- A exclusão exige justificativa e envia o registro para uma lixeira própria da quilometragem.
- Registros na lixeira deixam de aparecer na lista principal e ficam fora dos indicadores, relatórios, liberação de ciclos e validação de duplicidade.
- A seção “Registros excluídos” permite consultar o registro e restaurá-lo com justificativa.
- A restauração é bloqueada se já existir outro expediente ativo para o mesmo veículo e data.
- A exclusão é bloqueada se o expediente estiver vinculado a ciclos ou a ciclos antigos do mesmo veículo/data sem vínculo explícito. Nesses casos, use “Editar KM inicial/final” para corrigir o veículo, preservando a operação.
- Exclusão e restauração ficam registradas na Auditoria.

PRESERVAÇÃO DE DADOS
- A exclusão é lógica: não apaga fisicamente o registro.
- Backups completos continuam incluindo registros ativos e excluídos, para permitir recuperação.
- Banco de dados permanece orbita-v2 / versão 4. Não há migração, limpeza, renumeração ou sobrescrita de históricos/backups anteriores.
- O perfil Consulta continua somente leitura e não recebe os botões de excluir/restaurar.

PUBLICAÇÃO
Substitua os arquivos pelos desta atualização no repositório do GitHub Pages. Não limpe os dados do site nem os dados do navegador.

## ATUALIZACAO_V5.21.txt

ÓRBITA v5.21 — FUNDO ORBITAL ANIMADO

- Adicionada uma animação vetorial de fundo com uma Hyundai HR de entregas Nilo orbitando uma esfera luminosa identificada como ÓRBITA.
- A animação fica presente em todas as abas, atrás dos painéis e sem bloquear cliques ou formulários.
- Ajustes responsivos para computador e celular.
- Efeitos discretos e respeito à preferência do dispositivo por movimento reduzido.
- Animação feita em SVG/CSS, sem vídeo ou GIF pesado e sem timers JavaScript.
- Nenhuma tela operacional, regra de negócio, registro, tabela ou estrutura de banco foi alterada.
- Nenhuma migração, renumeração, exclusão ou regravação de histórico/backups foi executada.
- Banco orbita-v2 / versão 4 mantido sem alterações.

## ATUALIZACAO_V5.22.txt

ÓRBITA v5.22 — ROTEIRIZAÇÃO POR CICLO

- Cria uma ordem de rota separada para cada ciclo, sem alterar o número original das entregas.
- Exibe posição na rota, número original, cliente, endereço, bairro e prioridade em vermelho.
- Prioritárias permanecem antes das normais.
- Permite ajustar manualmente a ordem dentro de cada grupo de prioridade.
- Inclusões e retiradas de entregas atualizam a lista de rota do ciclo.
- Agrupamento inicial usa a ordem de bairros já cadastrada no sistema. Não calcula distância real de ruas sem serviço de mapas/geocodificação.
- Não altera a versão do IndexedDB, não limpa tabelas e não regrava históricos ou backups existentes.

## BAIRROS_ANALISADOS_V22.txt

NILO ENTREGAS • V22 — AUDITORIA DE BAIRROS E ROTEIRIZAÇÃO
Data da análise: 25/08/2026

PONTO DE PARTIDA
- Fixo: NILO Supermercado — Nova Xavantina/MT
- Endereço principal usado: Rua Teresina, 729, Novo Horizonte, Nova Xavantina - MT, 78690-000.
- O Google Maps é aberto com o Place ID específico da unidade NILO de Nova Xavantina.
- O roteirizador tenta também Avenida Araés, 729 e Rua Terezina, 681 como variantes cadastrais caso o geocodificador aberto não reconheça a grafia principal.

35 BAIRROS ATIVOS ENCONTRADOS NO SISTEMA
1 BARRO VERMELHO
2 BOA VISTA
3 CENTRO I
4 CENTRO II
5 CENTRO OESTE
6 CHACARAS
7 CONAGRO
8 DEUS E AMOR
9 ESTILAC
10 FLOR DE LIZ/LYZ
11 HENRRY I
12 HENRRY II
13 JARDIM ALVORADA
14 JARDIM OLIVEIRA
15 JARDIM TROPICAL
16 JARDIM TROPICAL II
17 JARDIM TROPICAL III
18 MONTES CLAROS
19 MORADA DO SOL
20 NOVO HORIZONTE
21 OLARIA
22 PARQUE DOS BURITIS
23 SANTA ANA / SANTANA
24 SANTA MÔNICA
25 SETOR INDUSTRIAL
26 SOLAR DOS IPÊS
27 TONETTO
28 UNIÃO
29 VERDES CAMPOS
30 VILA DO ESTUDANTE
31 ZONA RURAL
32 BEIRA RIO
33 SETOR NOVA XAVANTINA
34 PRIMITIVO
35 PARQUE AQUARIO

TRATAMENTOS DE MAPA IMPORTANTES
- CENTRO I: Setor Xavantina / Xavantina Velha; usa Av. Brasil Central como referência de fallback.
- CENTRO II: Setor Nova Brasília / Centro Comercial; usa Av. Rio Grande do Sul como referência de fallback.
  Eles NÃO são misturados, pois ficam em lados diferentes do Rio das Mortes.
- BARRO VERMELHO -> procura também como BAIRRO VERMELHO.
- ESTILAC -> procura também como ESTILAC LEAL.
- FLOR DE LIZ/LYZ -> tenta FLOR DE LIZ, FLOR DE LYZ e FLOR DE LIS.
- HENRRY I / II -> corrige a consulta do mapa para HENRY I / HENRY II / Mario Duílio Henry.
- SANTA ANA / SANTANA -> tenta SANTANA e SANTA ANA.
- TONETTO -> tenta TONETTO, TONETO, TONETTO I e TONETTO II.
- VERDES CAMPOS -> tenta VERDES CAMPOS e CAMPOS VERDES.
- ZONA RURAL: exige endereço/referência mais precisa; bairro sozinho não é suficiente.

ÁREAS NOVAS/OFICIAIS JÁ RECONHECIDAS PELO V22, MESMO QUE AINDA NÃO ESTEJAM NO CADASTRO-MESTRE
- Loteamento Nossa Senhora Aparecida
- Loteamento Colina Verde
- Loteamento Águas da Mata
- Lisnner
- Henry III
- Mario Duílio Henry
- Xavantina Velha / Central
- Tonetto I
- Tonetto II

ALERTA DE QUALIDADE DOS DADOS
O histórico atual possui centenas de entregas com bairro, mas pouquíssimas têm Rua + Número completos.
Para registros antigos, a rota será aproximada pelo bairro/área.
Para novas entregas, Rua/Avenida + Número devem ser preenchidos para o traçado chegar ao ponto real do cliente.

A V22 NÃO renomeia nem apaga seus bairros. Ela cria uma camada de compatibilidade de mapa.

## CHECKLIST_SEGURANCA.txt

CHECKLIST DE SEGURANÇA
======================
[ ] Fazer backup antes de publicar.
[ ] Não apagar app.js.
[ ] Não apagar arquivos de sincronização.
[ ] Não limpar localStorage/dados.
[ ] Não alterar Supabase.
[ ] Publicar somente index.html atualizado + nilo-approved-v32.js.
[ ] Testar no PC.
[ ] Testar no celular.
[ ] Confirmar entregas, rotas, relatórios, cadastros, backup e treinamento.

## CHECKLIST_SEGURANCA_V33.txt

CHECKLIST DE SEGURANÇA — V33

[OK] Não apaga IndexedDB.
[OK] Não limpa localStorage.
[OK] Não altera Supabase.
[OK] Não altera o modelo de dados.
[OK] Não remove IDs/data-view dos botões originais.
[OK] Não substitui V31 operacional.
[OK] Não substitui backup automático V32.
[OK] Mantém Entrega Grande / múltiplas viagens.
[OK] Mantém devolvidas e relançamento em novo ciclo.
[OK] Mantém rotas V24 e análises V19.

## CHECKLIST_V5.7.txt

ÓRBITA v5.7 — CHECKLIST DOS AJUSTES SOLICITADOS

[OK] Numeração usa a DATA REAL DA COMPRA (entryTime/operationDate).
[OK] Entrega agendada participa da mesma sequência diária da compra normal.
[OK] Data/hora agendada não cria numeração separada.
[OK] Próximo Nº da entrega aparece no formulário antes de salvar.
[OK] Nº de chegada removido do formulário; internamente novos registros recebem o mesmo número para compatibilidade.
[OK] Número continua editável manualmente em registros existentes.
[OK] Fluxo do cliente usa um único horário: Hora da entrega ao cliente.
[OK] O mesmo horário é gravado internamente em chegada/finalização para manter compatibilidade com históricos e relatórios antigos.
[OK] Não existe mais ação separada "Chegou no cliente" seguida de outro horário de finalização.
[OK] Seleção do ciclo reorganizada e checkbox limitado a 18px, sem esmagar o texto.
[OK] Taxa entra na receita assim que a compra é registrada; reembolso é descontado separadamente.
[OK] Nenhuma renumeração automática de registros antigos na abertura.
[OK] Cache PWA atualizado para v5.7.

TESTES
- JavaScript: sintaxe validada em app.js, db.js, helpers.js, views.js, excel-report.js e sw.js.
- CSS: 0 erros de parser.
- HTML: 0 IDs duplicados e 0 referências locais ausentes.
- Cenário de numeração: 20 registros de 02/09 + agendada antiga erroneamente #27 => próximo número calculado = #21.

## CHECKLIST_V33_5.txt

CHECKLIST V33.5
[ ] Central visual aprovado
[ ] Entregas & Programadas
[ ] Registro: compra sem duplicidade
[ ] Tipo normal/grande
[ ] Taxa
[ ] Entrega/agendamento
[ ] Endereço e cliente
[ ] Ciclos & Rotas
[ ] Frota com imagens aprovadas
[ ] Botões de frota alinhados
[ ] Análises & Relatórios
[ ] Administração & Cadastros
[ ] Mobile
[ ] Backup e sincronização preservados

## CHECKLIST_V33_6.txt

CHECKLIST V33.6
[ ] Visual atual preservado
[ ] Encerrar/Reabrir dia
[ ] Custos completos
[ ] Categorias de custo
[ ] Programadas/Reagendadas
[ ] Pendências
[ ] Pesquisa e histórico completo
[ ] Montar saída
[ ] Detectar/reutilizar saídas
[ ] Editar/gerenciar/fechar ciclo
[ ] Histórico GPS real
[ ] Google Maps
[ ] Abrir/Fechar/Editar KM
[ ] Dashboard completo
[ ] Relatórios completos
[ ] Análise por bairro
[ ] Cadastros completos
[ ] Lixeira completa
[ ] Treinamento
[ ] Backup/sincronização preservados

## CHECKLIST_VISUAL_V33_3.txt

CHECKLIST V33.3
[ ] sem faixa branca lateral
[ ] topo acompanha menu
[ ] menu aberto = Nilo no topo, Triela + mascote + status embaixo
[ ] menu recolhido = trilho estreito + Nilo/Triela no topo da barra principal
[ ] amarelo apenas em destaques/CTA/menu ativo
[ ] cards brancos com ícones coloridos
[ ] Registrar compra em 5 etapas
[ ] Entrega normal e entrega grande preservadas
[ ] Ciclos/rotas preservados
[ ] Quilometragem preservada
[ ] Relatórios preservados
[ ] Administração/cadastros preservados
[ ] Treinamento preservado
[ ] Mobile com dock inferior e Registrar compra amarelo
[ ] favicon mascote corpo inteiro

## GUIA_ATUALIZACAO_V4.md

# Guia de atualização para a V4

## O que foi corrigido

A V4 separa definitivamente duas coisas diferentes:

1. **Quilometragem diária do veículo**
   - KM inicial: antes de começar o expediente.
   - KM final: ao terminar o expediente.
   - KM rodado no dia = KM final - KM inicial.

2. **Ciclos de entrega**
   - 1 ciclo = 1 saída da loja até 1 retorno ao mercado.
   - Uma saída pode levar uma ou várias entregas.
   - Todas as entregas levadas juntas recebem o mesmo ciclo.

Com isso, o sistema calcula automaticamente:

- KM total por dia, semana, mês, ano e período personalizado;
- KM médio por ciclo;
- KM por entrega;
- entregas levadas por ciclo;
- média de ciclos por dia;
- tempo médio dos ciclos.

## Como atualizar seu GitHub Pages

1. Abra seu app atual e faça um **Backup JSON**.
2. Extraia o ZIP da V4.
3. Entre no mesmo repositório do GitHub.
4. Substitua os arquivos antigos pelos arquivos da V4.
5. Faça o commit.
6. Aguarde a publicação do GitHub Pages.
7. Abra o app e use `Ctrl + F5` no computador, caso o navegador ainda mostre arquivos antigos.

## Compatibilidade com dados anteriores

A V4 mantém o mesmo banco IndexedDB e o mesmo nome de base. Ao atualizar no mesmo endereço do GitHub Pages e no mesmo navegador, os registros anteriores continuam disponíveis.

Por segurança, faça backup antes da atualização.

## GUIA_ATUALIZACAO_V5.md

# Atualização para V5 Premium

1. Abra o app atual e faça um **Backup JSON**.
2. Baixe e extraia o ZIP da V5.
3. No repositório atual do GitHub, use **Add file > Upload files**.
4. Envie todos os arquivos da V5 para a raiz, substituindo os antigos.
5. Confirme o commit.
6. Aguarde o GitHub Pages publicar.
7. Abra o site e use `Ctrl + Shift + R` no PC para forçar atualização.
8. No celular, feche e abra novamente o PWA. Se ainda aparecer versão antiga, abra pelo navegador e atualize.

## Teste recomendado

1. Crie duas entregas.
2. Monte um ciclo com uma delas.
3. Abra **Ciclos > Gerenciar entregas**.
4. Adicione a segunda entrega.
5. Remova a primeira.
6. Confira se o total do ciclo e os indicadores foram recalculados.

## GUIA_ATUALIZACAO_V6.md

# Atualização para a V6

1. Abra o app atual e faça **Backup** dos dados.
2. Baixe e extraia o ZIP da V6.
3. No mesmo repositório do GitHub Pages, substitua todos os arquivos pelos arquivos da V6.
4. Confirme o commit.
5. Aguarde a publicação.
6. Abra o site e pressione **Ctrl + F5** no computador. No celular, feche e abra o app novamente.

## Novidades
- Novo layout completo.
- Ambiente **Operação real** e **Treinamento** separados.
- Dados de exemplo para treinamento.
- Limpeza de treinamento sem afetar dados reais.
- Apagar entregas, ciclos, KM e custos.
- Lixeira com restauração e exclusão definitiva.

## Regra de segurança
Itens apagados vão para a **Lixeira**. Só somem definitivamente quando você confirmar a exclusão permanente.

## GUIA_ATUALIZACAO_V7.md

# Atualização para V7

1. Abra o app atual e faça um Backup JSON.
2. Baixe o ZIP da V7 e extraia os arquivos.
3. No mesmo repositório GitHub Pages, substitua `index.html`, `styles.css`, `app.js`, `sw.js`, `manifest.webmanifest`, `VERSION.txt`, `.nojekyll` e a pasta `icons`.
4. Faça commit.
5. Aguarde a publicação e abra o site com `Ctrl + Shift + R`.
6. Se ainda aparecer a versão antiga, abra em janela anônima ou limpe os dados do site/service worker.

Os dados continuam usando o mesmo banco local IndexedDB e são compatíveis com a V6.

## GUIA_ATUALIZACAO_V8.md

# Atualização para V8 — Foco Médio-Escuro

1. Abra o app atual e faça **Backup JSON**.
2. Extraia o ZIP da V8.
3. No mesmo repositório GitHub Pages, substitua os arquivos da raiz pelos da V8.
4. Confirme o commit.
5. Aguarde a publicação do GitHub Pages.
6. Abra o site e use `Ctrl + Shift + R` ou uma janela anônima se a versão antiga aparecer por cache.

A V8 mantém a estrutura de dados e as funções da V7; a mudança principal é visual e de hierarquia para deixar o uso mais rápido, concentrado e menos confuso.

## GUIA_ATUALIZACAO_V9.md

# Atualização para V9 — Paleta Nilo Supermercado

1. Faça Backup JSON no app atual.
2. Extraia o ZIP da V9.
3. No mesmo repositório do GitHub, substitua os arquivos da raiz pelos da V9.
4. Faça commit.
5. Aguarde o GitHub Pages publicar.
6. Abra o site e use Ctrl+Shift+R.
7. Se ainda aparecer a versão antiga, abra em janela anônima ou limpe o cache do site/PWA.

A V9 mantém os dados compatíveis com a V8 e altera principalmente identidade visual, contraste e foco.

## GUIA_ATUALIZACAO_V10.md

# Guia de atualização • V10

1. Faça um **Backup JSON** no app atual.
2. Extraia o ZIP da V10.
3. No mesmo repositório do GitHub Pages, substitua os arquivos da raiz pelos arquivos desta versão.
4. Faça o commit.
5. Aguarde a publicação.
6. Abra o app e faça `Ctrl + F5` ou teste em janela anônima para forçar a atualização do cache.

A V10 mantém o mesmo banco IndexedDB e foi preparada para preservar os dados existentes no mesmo navegador e endereço do app. Mesmo assim, o backup antes da atualização é obrigatório por segurança.

## GUIA_ATUALIZACAO_V11.md

# Atualização para V11

1. Abra a versão atual do sistema e faça **Backup JSON**.
2. Extraia o ZIP da V11.
3. No repositório do GitHub Pages, substitua os arquivos da raiz pelos arquivos da V11.
4. Faça o commit.
5. Aguarde a publicação do GitHub Pages.
6. Abra o site e pressione **Ctrl + F5**.
7. Confirme que o menu mostra **Central de Operação** e que a tela inicial exibe a V11.

## Compatibilidade
A V11 mantém o mesmo banco local IndexedDB e migra automaticamente os dados antigos para o ambiente real.

## Novidade de encerramento
O sistema cria um checkpoint do dia e bloqueia o encerramento enquanto houver ciclo aberto, entrega em rota ou KM final pendente de veículo que trabalhou. O dia pode ser reaberto para correções.

## GUIA_ATUALIZACAO_V12.md

# Atualização para V12 — Visibilidade Total

Esta versão parte da V11 e mantém as funções já existentes. O foco é corrigir a legibilidade em toda a aplicação.

## O que foi corrigido

- Nomes de bairros em registros, tabelas, listas e seletores.
- Textos escuros sobre fundos escuros.
- Títulos, subtítulos, labels, campos, placeholders e opções de listas.
- Tabelas de entregas, ciclos, KM, custos, cadastros e análise por bairro.
- Cards operacionais, modais, pendências e telas de treinamento.
- Contraste dos botões, badges e estados.
- Ícones de data e hora em campos escuros.
- Número da compra e nome do bairro mais destacados nos registros.

## Como atualizar no GitHub

1. Faça Backup JSON no sistema atual.
2. Extraia o ZIP da V12.
3. Envie os arquivos da V12 para a raiz do mesmo repositório do GitHub Pages, substituindo os arquivos antigos.
4. Confirme o commit.
5. Aguarde a publicação.
6. Abra o site e pressione Ctrl + F5.
7. Confirme no rodapé: V12.0.0.

A V12 usa um novo nome de cache do service worker para reduzir o risco de a versão antiga continuar presa no navegador.

## GUIA_ATUALIZACAO_V13.md

# Atualização para V13 — Ciclos Automáticos por Saída Conjunta

## O que mudou

A V13 identifica automaticamente como um único ciclo todas as entregas que saem juntas.

A regra é:

- mesma data;
- mesma hora de saída;
- mesmo veículo;
- mesmo entregador.

Exemplo:

- Compra 31 — saída 10:30 — Strada 01 — João
- Compra 32 — saída 10:30 — Strada 01 — João
- Compra 33 — saída 10:30 — Strada 01 — João

Resultado: as três entregas recebem automaticamente o mesmo ciclo, por exemplo `CIC-20260714-03`.

Cada entrega continua tendo seu próprio horário de finalização na casa do cliente. O ciclo só termina quando o retorno ao mercado é registrado.

## Saídas antigas sem ciclo

Na tela **Ciclos**, use o botão **Detectar saídas já registradas**. O sistema procura entregas sem ciclo e agrupa automaticamente as que representam a mesma saída real.

## Como atualizar no GitHub Pages

1. Faça um **Backup JSON** no sistema atual.
2. Extraia o ZIP da V13.
3. Envie os arquivos para a raiz do mesmo repositório do GitHub Pages, substituindo os arquivos antigos.
4. Confirme o commit.
5. Aguarde a publicação.
6. Abra o site e pressione **Ctrl + F5**.
7. Confirme no rodapé: **V13.0.0**.

A V13 usa o cache `controle-entregas-v13-ciclos-automaticos` para reduzir o risco de a versão antiga continuar presa no navegador.

## GUIA_ATUALIZACAO_V14.md

# Guia de atualização para a V14

## Antes de publicar

1. Abra a versão atualmente usada na operação.
2. Clique em **Backup** e guarde o arquivo JSON em local seguro.
3. Não apague os dados do navegador antes de confirmar que o backup foi baixado.

## Publicação no GitHub Pages

Substitua somente os arquivos principais da raiz:

- `index.html`
- `styles.css`
- `app.js`
- `sw.js`
- `manifest.webmanifest`
- `README.md`
- `VERSION.txt`

As pastas de versões antigas podem permanecer como histórico, mas não são utilizadas pelo endereço principal.

## Primeira abertura após a publicação

1. Abra o sistema com internet.
2. Recarregue a página uma vez para garantir a ativação do novo modo offline.
3. Confira no rodapé se aparece **V14.4.3**.
4. Abra **Cadastros > Dados** e faça um novo backup.
5. Se precisar conferir a cópia de segurança automática, use **Backup antes da atualização**.

## Teste mínimo recomendado

Use o modo **Treino** para confirmar:

- cadastro de uma compra;
- cálculo em tempo corrido de compra até saída e de compra até finalização no cliente;
- indicação de saída fora do padrão acima de 2h, entrega fora do padrão acima de 3h30 e prazo restante;
- pesquisa na tela Entregas por número da compra, nº do cupom, DOC, caixa, dia e nome do cliente;
- pesquisa na tela Pesquisar Entregas por nº automático da compra/entrega, cupom, data, DOC, caixa e cliente;
- preenchimento de Nº DO CUPOM, Nº do DOC e Nº do caixa;
- preenchimento opcional de nome e telefone do cliente;
- montagem de uma saída;
- fechamento do ciclo;
- KM inicial e final;
- registro de custo;
- geração de relatório;
- conferência das 31 abas do relatório Excel, incluindo `PREVISAO_MOVIMENTO`, `SLA_PRAZOS`, `FLUXO_OPERACIONAL` e `RESUMO_MENSAL`;
- conferência da formatação em R$, %, h/min e km;
- visualização dos novos gráficos no Dashboard e na impressão/PDF;
- conferência de uma compra programada ou reagendada que tenha sido entregue em uma tentativa posterior: ela deve aparecer como entregue, e não como programação aberta;
- conferência da aba `PROGRAMADAS` no Excel e da seção equivalente no PDF, com situação consolidada e data/hora da entrega;
- conferência, nos principais insights, da data com mais entregas em dia/mês/ano;
- conferência do dia da semana e da semana do mês com maior média, junto do período histórico usado no cálculo;
- conferência, no Dashboard, do dia e da semana previstos como mais movimentados nas próximas 5 semanas;
- conferência da aba `PREVISAO_MOVIMENTO` e do nível de confiança da estimativa;
- prévia de restauração de backup, cancelando antes da substituição.

## Compatibilidade

A V14.4.3 mantém os dados da V14.4.2, V14.4.1, V14.4.0, V14.3.8, V14.3.7, V14.3.6, V14.3.5, V14.3.4, V14.3.3, V14.3.2, V14.3.1, V14.3, V14.2, V14.1, V14, V13 e das versões anteriores reconhecidas pelo sistema. A previsão é somente leitura e recalculada automaticamente; ela não altera entregas, programações ou históricos. Na primeira abertura, nenhum registro, ciclo, custo, KM ou configuração é removido. Backups de uma versão futura são bloqueados para evitar perda de informações.

## GUIA_ATUALIZACAO_V14_5.md

# Atualização V14.5.0

## O que mudou

- Agendamentos agora registram dia, hora e detalhes adicionais.
- Entregas que pertencem a uma cadeia agendada ficam fora do indicador comum de atraso.
- Ao fechar um ciclo, o sistema pergunta se alguma entrega voltou sem ser entregue.
- Quando a resposta é **Sim**, aparecem somente as NFs ainda não finalizadas. Cada NF marcada exige o motivo da volta e aceita um detalhe complementar.
- Nomes de clientes e nomes de bairros são salvos em caixa alta.
- Telefones são formatados como `( 99 ) 9 9999-9999`.

## Como publicar no GitHub Pages

1. Abra o repositório `prevencaoredenilo-ux/controle-entregas` no GitHub.
2. Envie os arquivos do pacote V14.5.0 para a raiz do repositório, substituindo os arquivos com o mesmo nome.
3. Confirme o envio na branch `main`.
4. Aguarde a atualização do GitHub Pages e recarregue o sistema. Se a versão antiga ainda aparecer, feche e abra o aplicativo novamente para atualizar o cache offline.

Os dados existentes continuam armazenados no mesmo banco local. Na primeira abertura da V14.5.0, o sistema cria uma cópia de segurança local da versão anterior antes da migração.

## GUIA_ATUALIZACAO_V14_6.md

# Atualização V14.6.0 • celular, tempo real e modo offline

## Primeiro acesso

1. Publique os arquivos da V14.6.0 na raiz do GitHub Pages.
2. Abra o sistema com internet no computador que já possui os dados operacionais.
3. Entre com o mesmo usuário e a mesma senha cadastrados no sistema Nilo.
4. Aguarde aparecer **Sincronizado em tempo real**. No primeiro acesso, os dados locais desse computador serão enviados para o banco online.
5. Abra o mesmo endereço no celular e entre com a mesma conta. O celular carregará os dados do banco.

## Funcionamento sem internet

- O sistema continua abrindo e salvando no aparelho depois que o primeiro acesso online foi concluído.
- O indicador lateral mostra quantas alterações aguardam sincronização.
- Quando a internet volta, a fila é enviada automaticamente.
- Enquanto um aparelho estiver offline, ele não receberá mudanças dos outros aparelhos. As atualizações aparecem quando ele se reconectar.

## Segurança

- O aplicativo usa somente a chave publicável no navegador; nenhuma chave administrativa fica no código.
- As tabelas `delivery_workspaces`, `delivery_workspace_members` e `delivery_sync_entities` têm RLS ativado.
- Os dados de entregas ficam separados das tabelas do outro sistema que utiliza o mesmo projeto Supabase.

## Arquivos que precisam ser enviados

- `.nojekyll`
- `index.html`
- `app.js`
- `styles.css`
- `sw.js`
- `manifest.webmanifest`
- `VERSION.txt`
- pasta `icons`

Se uma versão antiga continuar aparecendo, feche todas as abas do sistema, abra novamente com internet e aguarde a troca do cache offline para V14.6.0.

## GUIA_ATUALIZACAO_V14_7.md

# Atualização V14.7.1 • roteirização e visual para celular

## Publicação

1. Faça um Backup JSON no sistema atual.
2. Publique os arquivos da V14.7.1 na raiz do GitHub Pages.
3. Abra o sistema com internet e confirme que o rodapé mostra **V14.7.1**.
4. No computador que já possui os dados, entre na conta e aguarde a mensagem **Sincronizado em tempo real**.
5. Depois abra o sistema no celular.

## Preparação da rota

1. Acesse **Cadastros > Regras**.
2. Confira o ponto de saída e retorno do mercado.
3. Confira a cidade usada pelo Google Maps.
4. Acesse **Cadastros > Bairros** e defina a ordem de atendimento de cada bairro.

Números menores aparecem primeiro no roteiro, exceto quando existe entrega prioritária.

## Cadastro da entrega

- Bairro continua obrigatório.
- Rua/avenida e número são recomendados para o Google Maps localizar a porta do cliente.
- Complemento e referência ajudam o entregador, mas não alteram o cálculo do mapa.
- Ao marcar **Entrega prioritária**, a NF fica no começo do roteiro do ciclo.

Se uma entrega antiga tiver somente o bairro, ela não é bloqueada: o mapa usa uma parada aproximada pelo bairro e o roteiro avisa que falta o endereço exato.

## Montagem do ciclo

1. Toque em **Montar nova saída**.
2. Selecione as entregas.
3. Confira o quadro **Roteiro sugerido**.
4. Confirme a saída.
5. No cartão do ciclo, use **Rota no Google Maps**.

A ordem aplicada é:

1. entregas prioritárias;
2. ordem configurada dos bairros;
3. endereço dentro do bairro;
4. horário de entrada como desempate.

## Internet e modo offline

- A lista e a ordem do roteiro ficam salvas no aplicativo e podem ser consultadas offline.
- Para abrir o Google Maps e calcular as ruas, é necessário estar conectado à internet.
- Entregas e ciclos lançados offline continuam na fila e sincronizam quando a conexão voltar.

## Uso no celular

A barra inferior oferece acesso rápido à Central, Ciclos, Nova compra e Menu. Os formulários passam para uma coluna e os botões principais ficam maiores para reduzir erros de toque.

## GUIA_ATUALIZACAO_V14_8.md

# Atualização V14.8.0 • histórico de rotas GPS

## Antes de publicar

1. No sistema atual, gere um **Backup JSON** em Cadastros > Dados.
2. Publique todos os arquivos da V14.8.0 na raiz do GitHub Pages, incluindo a pasta `icons`.
3. Abra o sistema com internet e confirme que o rodapé mostra **V14.8.0**.
4. Atualize a página uma segunda vez para garantir a troca do cache offline.

## Verificação rápida

1. Confirme que todos os itens antigos do menu continuam disponíveis e que **Relatórios** permanece separado.
2. Abra **Histórico de rotas** e teste os filtros Hoje, semana, mês e período específico.
3. Pelo celular, monte um ciclo, permita a localização e confirme que o botão mostra **GPS ativo**.
4. Faça um pequeno deslocamento, feche o ciclo e confirme se o trajeto aparece no histórico.
5. Gere um novo Backup JSON e confirme que a prévia da restauração mostra a quantidade de **Rotas GPS**.

## Observações importantes

- O GPS do aparelho funciona sem internet e os pontos são sincronizados quando a conexão volta.
- O Google Maps precisa de internet para calcular e exibir as ruas.
- Mantenha o aplicativo aberto durante a rota. Navegadores móveis podem pausar a localização se a página for fechada ou o sistema operacional suspender o aplicativo.
- Nenhuma alteração de banco é necessária: os trajetos usam a mesma estrutura genérica e protegida de sincronização das demais entidades.

## LEIA-ME.txt

NILO ENTREGAS — V33.3 CORREÇÃO DEFINITIVA

SUBSTITUA ESTES 4 ARQUIVOS NA RAIZ DO REPOSITÓRIO:
1. index.html
2. public-sync.js
3. nilo-approved-v33.js
4. sw.js

O que esta correção resolve:
- remove o carregamento visual antigo V32;
- ativa diretamente o visual aprovado V33.2;
- mantém V31 operacional;
- mantém backup automático no Supabase;
- mantém rotas V24;
- mantém relatórios, cadastros, ciclos e dados;
- padroniza Triela + mascote + status no menu;
- mantém menu e mobile da versão aprovada;
- usa cache novo para evitar versão antiga presa no navegador.

Depois do upload:
aguarde o GitHub Pages atualizar e faça Ctrl+F5 UMA VEZ.

## LEIA-ME-V34.txt

NILO ENTREGAS — V34 BASE VISUAL DEFINITIVA

Esta versão NÃO usa a camada visual V32/V33 como base.
Ela cria uma camada V34 limpa para eliminar os conflitos de largura e menu.

CORREÇÕES PRINCIPAIS
- aplicativo ocupa 100% da página;
- sem faixa branca lateral;
- topo acompanha imediatamente o menu;
- menu aberto 252 px; recolhido 76 px;
- mascote somente dentro do menu;
- logo Triela substituída pela imagem correta enviada;
- favicon/ícone do app usa o mascote de corpo inteiro;
- paleta navy + azul + amarelo + branco aprovada;
- mantém todos os botões/IDs/data-view e as funções existentes;
- não altera app.js, Supabase, backup ou V31 operacional.

SUBSTITUA/ADICIONE NA RAIZ DO GITHUB:
index.html
sw.js
manifest.webmanifest
nilo-approved-v34.js
nilo-v34.png
triela-v34.png
mascote-v34.png
favicon-v34.png

E substitua dentro da pasta icons:
icons/icon-192.png
icons/icon-512.png

NÃO PRECISA APAGAR nilo-approved-v33.js; o index V34 simplesmente deixa de carregá-lo.
Depois aguarde o Pages e faça Ctrl+F5 uma vez.

## LEIA-ME-V34-1.txt

NILO ENTREGAS — V34.1 AJUSTE MENU + MASCOTE

CORRIGE EXATAMENTE O PRINT:
- elimina a área branca riscada abaixo do menu;
- menu azul ocupa toda a altura da tela;
- ao recolher, fica somente a barra estreita de 76 px;
- ao abrir, fica com 252 px;
- conteúdo e barra superior acompanham automaticamente;
- mascote fica integrado ao menu, sem aquela moldura/quadro aparente;
- Triela permanece acima do mascote;
- status permanece abaixo.

NÃO ALTERA:
dados, Supabase, backup, entregas, ciclos, rotas, relatórios ou V31 operacional.

SUBSTITUA NA RAIZ:
index.html
nilo-approved-v34.js
sw.js

Os demais arquivos V34 permanecem.

## LEIA-ME_ATUALIZACAO_V15_1.txt

ATUALIZAÇÃO NILO • V15.1 • SEM SENHA + TEMPO REAL

O QUE ESTA ATUALIZAÇÃO FAZ
- mantém o layout V15 aprovado;
- não pede usuário;
- não pede senha;
- abre o sistema diretamente;
- mantém os dados no aparelho para continuar funcionando sem internet;
- quando a internet volta, sincroniza novamente;
- dados ficam compartilhados entre PC, celular e outros aparelhos;
- mantém Central de Operação, Dashboard, Entregas, Programadas, Pendências,
  Ciclos, Quilometragem, Rotas dos entregadores, Custos, Bairros,
  Pesquisa, Relatórios, Lixeira, Cadastros e Backup;
- mantém Desempenho diário e Entregas do dia;
- não adiciona Ranking de entregadores.

ARQUIVOS DESTA ATUALIZAÇÃO
1. index.html                 -> substituir o index.html atual
2. nilo-layout-v15.css        -> enviar para a raiz
3. public-sync.js             -> enviar para a raiz

NÃO APAGUE
- app.js
- styles.css
- manifest.webmanifest
- sw.js
- pasta icons
- os demais arquivos existentes no repositório

COMO ATUALIZAR NO GITHUB
1. Abra o repositório controle-entregas.
2. Entre na raiz (onde estão index.html, app.js e styles.css).
3. Faça upload dos 3 arquivos desta pasta.
4. Confirme a substituição do index.html.
5. Confirme o commit.
6. Aguarde o GitHub Pages atualizar.
7. Abra o sistema e pressione Ctrl+F5 no PC. No celular, feche e abra novamente.

BANCO EM TEMPO REAL
A estrutura necessária no Supabase já foi preparada para o workspace
"nilo-entregas". Não é necessário criar usuário ou senha.

IMPORTANTE SOBRE ACESSO SEM SENHA
Como solicitado, o sistema não possui barreira de login para estes dados.
Quem tiver acesso ao link publicado poderá abrir o sistema. Portanto,
não compartilhe o link publicamente com pessoas que não devem acessar
ou alterar os dados.

SEGURANÇA DA ATUALIZAÇÃO
Esta versão não substitui app.js nem styles.css originais. Ela acrescenta:
- uma camada visual (nilo-layout-v15.css);
- uma camada de sincronização sem login (public-sync.js).
Assim, as regras de negócio existentes permanecem no app.js V14.8.

## LEIA-ME_CORRECAO_V15_2.txt

CORREÇÃO NILO • V15.2 • TRAVAMENTO DA PÁGINA

MOTIVO DA CORREÇÃO
A V15.1 possuía uma rotina que observava a tela de acesso e, ao mesmo tempo,
alterava essa mesma tela. Em alguns navegadores isso podia gerar chamadas
repetidas e o Chrome exibia "Página sem resposta".

A V15.2 remove essa rotina e deixa a sincronização mais leve.

O QUE VOCÊ PRECISA SUBSTITUIR
1. index.html
2. public-sync.js

NÃO APAGUE NENHUM OUTRO ARQUIVO.
Não mexa no app.js, styles.css, nilo-layout-v15.css, manifest, sw.js ou icons.

DEPOIS DE PUBLICAR
1. Aguarde o GitHub Pages atualizar.
2. Feche a aba antiga que travou.
3. Abra novamente:
   https://prevencaoredenilo-ux.github.io/controle-entregas/
4. No PC pressione CTRL + F5 uma vez.
5. No celular feche o navegador/app e abra novamente.

A versão do public-sync foi alterada para 15.2 no index.html para impedir
que o navegador reutilize o JavaScript 15.1 que ficou em cache.

CONTINUA MANTENDO
- sem usuário e sem senha;
- dados compartilhados em tempo real;
- funcionamento local/offline;
- layout V15;
- funções e relatórios existentes do app.js;
- Desempenho diário;
- Entregas do dia;
- sem Ranking de entregadores.

## LEIA-ME_CORRECAO_VISUAL_V32.txt

CORREÇÃO VISUAL V32 APROVADA

Arquivos para enviar à raiz do GitHub:
1. public-sync.js
2. sw.js
3. nilo-approved-v32.js

Substitua os arquivos existentes com esses nomes.
O index.html NÃO precisa ser alterado nesta correção.

O que esta correção faz:
- ativa a camada visual aprovada V32;
- mantém V31 operacional;
- mantém backup automático V32;
- mantém Supabase, dados, rotas, relatórios e cadastros;
- força novo cache do aplicativo para evitar continuar vendo o visual antigo.

Após publicar, aguarde o GitHub Pages atualizar e faça Ctrl+F5 uma vez.

## LEIA-ME_V16.txt

ATUALIZAÇÃO NILO • V16 • VISIBILIDADE + ROTAS DOS ENTREGADORES

ESTA VERSÃO CORRIGE EXATAMENTE OS DOIS PONTOS ALINHADOS:

1) SISTEMA INTEIRO — SOMENTE VISIBILIDADE
- aumenta contraste de textos;
- deixa inputs/selects/textarea claros e fáceis de enxergar;
- corrige placeholders apagados;
- melhora labels, textos auxiliares, tabelas e botões secundários;
- mantém a estrutura e o funcionamento das telas atuais.

2) ROTAS DOS ENTREGADORES — CORRIGE A DIFERENÇA DA PRÉVIA APROVADA
A tela passa a mostrar:
- Distância total;
- Tempo em rota;
- Entregas concluídas;
- Entregas retornadas;
- Entregadores ativos;
- Mapa das rotas;
- Entregas do dia;
- Desempenho diário;
- Resumo do período;
- Taxa de sucesso;
- Taxa de retorno;
- Total de tentativas;
- Tempo médio compra → cliente;
- Melhor dia da semana;
- Semana com mais entregas;
- Dia com mais entregas;
- Faixa horária com mais entregas.

O GPS CONTINUA EXISTINDO, MAS NÃO É MAIS O CENTRO DA ANÁLISE.
Mesmo sem pontos GPS, as informações operacionais aparecem usando os registros das entregas e ciclos.

ARQUIVOS DO ZIP
- index.html                     SUBSTITUIR
- public-sync.js                 SUBSTITUIR (correção V15.2 contra travamento)
- visibility-v16.css             NOVO
- route-view-v16.js              NOVO
- LEIA-ME_V16.txt                instruções

NÃO APAGUE
- app.js
- styles.css
- nilo-layout-v15.css
- manifest.webmanifest
- sw.js
- pasta icons

COMO ATUALIZAR
1. Abra a raiz do repositório controle-entregas no GitHub.
2. Faça upload dos 4 arquivos: index.html, public-sync.js, visibility-v16.css e route-view-v16.js.
3. Confirme a substituição de index.html e public-sync.js.
4. Faça o commit.
5. Aguarde o GitHub Pages atualizar.
6. Feche a aba antiga e abra novamente o sistema.
7. No PC use CTRL + F5 uma vez.

IMPORTANTE
Esta atualização não substitui app.js. As regras, registros, relatórios e cálculos existentes continuam no código original.

## LEIA-ME_V17.txt

NILO ENTREGAS • ATUALIZAÇÃO V17
VISIBILIDADE + ROTAS DOS ENTREGADORES + ROTEIRIZAÇÃO

O QUE ESTA VERSÃO CORRIGE
1. VISIBILIDADE GERAL
- corrige texto escuro em painéis escuros;
- melhora títulos e subtítulos da Lixeira;
- melhora Críticas / Atenção / Informativas;
- melhora as 31 abas do relatório;
- melhora Cadastros mestres;
- melhora labels de Pesquisar entregas;
- melhora labels e textos auxiliares dos formulários;
- mantém inputs claros e legíveis;
- não altera a estrutura das outras telas.

2. ROTAS DOS ENTREGADORES
Mantém a composição V16:
- Entregas do dia;
- Desempenho diário;
- Resumo do período;
- Taxa de sucesso;
- Taxa de retorno;
- Total de tentativas;
- Tempo médio compra → cliente;
- Melhor dia da semana;
- Semana com mais entregas;
- Dia com mais entregas;
- Faixa horária de maior movimento.

3. ROTEIRIZAÇÃO PLANEJADA
- não depende do GPS do entregador;
- usa Rua/Avenida + Número + Bairro já cadastrados;
- escolhe uma saída/ciclo;
- localiza as paradas;
- calcula um trajeto viário eficiente;
- mostra distância e tempo estimados;
- desenha a rota em mapa;
- lista a ordem das entregas;
- abre a sequência no Google Maps;
- entrega prioritária continua destacada.

OBSERVAÇÃO TÉCNICA SOBRE O MAPA
Para não exigir chave paga do Google Maps nesta versão:
- a localização/traçado automático no painel usa serviços abertos de mapa/roteamento;
- o botão de navegação abre a sequência final no Google Maps.
Se futuramente você quiser que o próprio cálculo seja feito pela API oficial do
Google Maps, será necessário habilitar Google Maps Platform e configurar uma
chave de API/faturamento.

ARQUIVOS DO ZIP
- index.html                      SUBSTITUIR
- visibility-v17.css              NOVO
- route-planner-v17.js            NOVO
- LEIA-ME_V17.txt

MANTER NO GITHUB
Não apague:
- app.js
- styles.css
- nilo-layout-v15.css
- visibility-v16.css
- route-view-v16.js
- public-sync.js
- manifest.webmanifest
- sw.js
- icons/

COMO ATUALIZAR
1. Abra a raiz do repositório controle-entregas.
2. Faça upload dos 3 arquivos: index.html, visibility-v17.css e route-planner-v17.js.
3. Confirme a substituição do index.html.
4. Faça o commit.
5. Aguarde o GitHub Pages atualizar.
6. Feche a aba antiga e abra novamente.
7. Pressione CTRL + F5 uma vez no PC.

IMPORTANTE
A atualização não substitui app.js e, portanto, mantém as regras e relatórios
existentes. Ela trabalha como camada de interface/roteirização sobre o sistema atual.

## LEIA-ME_V18.txt

NILO ENTREGAS • V18 • SOMENTE VISIBILIDADE

ESTA VERSÃO FAZ SÓ UMA COISA:
- corrige visibilidade / contraste / leitura.

O QUE ELA MELHORA
- labels dos campos;
- subtítulos;
- textos em fundos escuros;
- cards escuros;
- Lixeira de registros;
- Cadastros mestres;
- lista de relatórios;
- Pesquisar entregas;
- Histórico de rotas;
- Críticas / Atenção / Informativas;
- tabelas e textos auxiliares;
- modal de nova compra.

NÃO MUDA
- funções;
- cálculos;
- relatórios;
- roteirização da V17;
- sincronização.

ARQUIVOS DO ZIP
- index.html -> SUBSTITUIR
- visibility-v18.css -> NOVO
- LEIA-ME_V18.txt

MANTER NO GITHUB
- app.js
- styles.css
- nilo-layout-v15.css
- visibility-v16.css
- visibility-v17.css
- route-view-v16.js
- route-planner-v17.js
- public-sync.js
- manifest.webmanifest
- sw.js
- icons/

## LEIA-ME_V19.txt

NILO ENTREGAS • V19 ESTÁVEL

ESTA VERSÃO É UMA CONSOLIDAÇÃO, NÃO MAIS UMA CAMADA POR CIMA DAS OUTRAS.

CORRIGE VISIBILIDADE EM TODO O SISTEMA
- conteúdo principal usa cards claros e texto escuro forte;
- labels, subtítulos, placeholders e textos auxiliares ficam legíveis;
- Pesquisa, Relatórios, Cadastros e Pendências foram convertidos para superfícies claras;
- Lixeira e hero de Rotas continuam escuros, mas com texto branco real;
- Nova compra deixa de ter campos pretos;
- tabelas e indicadores ganham contraste consistente;
- sidebar verde-petróleo é mantida.

CORRIGE ESTABILIDADE
- remove o empilhamento de visibility-v16.css, visibility-v17.css e visibility-v18.css do index;
- remove os scripts antigos route-view-v16.js e route-planner-v17.js do index;
- usa versões estáveis dos scripts de rotas;
- remove setInterval de 1,2 s e 2,2 s;
- remove observador global do document.documentElement;
- atualiza o Service Worker para V19 e limpa caches antigos.

ARQUIVOS DO ZIP
- index.html -> SUBSTITUIR
- ui-stable-v19.css -> NOVO
- route-view-stable-v19.js -> NOVO
- route-planner-stable-v19.js -> NOVO
- sw.js -> SUBSTITUIR
- LEIA-ME_V19.txt

DEPOIS DE PUBLICAR
1. Aguarde o GitHub Pages concluir.
2. Feche todas as abas antigas do sistema.
3. Abra novamente o link.
4. No PC pressione CTRL+F5 uma vez.
5. Se o sistema estiver instalado como app/PWA, feche completamente e abra novamente.

IMPORTANTE
Os arquivos antigos visibility-v16.css, visibility-v17.css, visibility-v18.css,
route-view-v16.js e route-planner-v17.js podem continuar no repositório, mas a V19
NÃO os carrega mais. Portanto eles não interferem no sistema.

## LEIA-ME_V22.txt

NILO ENTREGAS • V22 — ORIGEM FIXA NILO + BAIRROS

ARQUIVOS PARA PUBLICAR
1. index.html -> substituir
2. route-planner-stable-v22.js -> novo
3. sw.js -> substituir
4. BAIRROS_ANALISADOS_V22.txt -> opcional, apenas documentação

NÃO APAGAR
- app.js
- public-sync.js
- styles.css
- nilo-layout-v15.css
- ui-stable-v19.css
- route-view-stable-v19.js
- manifest.webmanifest
- icons/

PRINCIPAIS CORREÇÕES
- O ponto de saída/retorno não é mais lido de uma configuração genérica: é sempre o NILO Supermercado de Nova Xavantina.
- Google Maps usa a unidade específica do NILO via Place ID.
- Centro I e Centro II são tratados como áreas diferentes em margens diferentes do Rio das Mortes.
- 35 bairros atuais receberam aliases de mapa.
- Nomes novos/alternativos foram incluídos na camada de roteirização.
- Endereço exato (rua + número) sempre tem prioridade sobre o bairro.
- Histórico sem endereço completo usa bairro como aproximação.
- Cache atualizado para V22.

DEPOIS DE PUBLICAR
Feche as abas antigas, abra o sistema novamente e pressione Ctrl+F5 uma vez.

## LEIA-ME_V23.txt

HOTFIX V23 — CORES EXATAS

Substituir somente:
- index.html
- sw.js

O que muda:
1. Histórico de entregas: letras das áreas marcadas no 1º print ficam pretas.
2. Ciclos de entrega: usa o mesmo padrão de cores do 4º print.
3. Quilometragem real da frota: usa o mesmo padrão de cores do 4º print.
4. Rotas dos entregadores: mantém o padrão do 4º print.

Depois de publicar:
- feche as abas antigas
- abra o sistema novamente
- pressione Ctrl+F5 uma vez

## LEIA-ME_V24.txt

NILO ENTREGAS • V24 — ROTA PLANEJADA

OBJETIVO
Mostrar a possível rota que o entregador deveria fazer, sem rastrear o GPS real.

O QUE MUDOU
- remove o erro "não foi possível localizar o NILO";
- não usa mais geocodificação automática para desenhar a rota;
- saída e retorno são sempre o NILO Supermercado em Nova Xavantina;
- o ciclo é organizado em uma sequência operacional sugerida;
- Centro I e Centro II continuam tratados separadamente;
- mostra uma prévia de direção;
- botão "Abrir rota no Google Maps";
- o Google Maps calcula o caminho pelas ruas entre as paradas;
- não precisa instalar nada no celular do entregador.

IMPORTANTE
A ordem das paradas é uma sugestão do sistema baseada nos bairros/regiões e na
ordem operacional cadastrada. Para otimização matemática oficial da ordem pelo
Google seria necessária uma chave da Google Maps Platform / Routes API.

ARQUIVOS PARA PUBLICAR
1. index.html -> SUBSTITUIR
2. route-planner-stable-v24.js -> NOVO
3. sw.js -> SUBSTITUIR

MANTER OS DEMAIS ARQUIVOS DO SISTEMA.

DEPOIS DE PUBLICAR
Feche as abas antigas, abra novamente e pressione Ctrl+F5 uma vez.

## LEIA-ME_V25.txt

NILO ENTREGAS • ATUALIZAÇÃO V25

Esta versão mantém a V24 aprovada e adiciona as correções solicitadas:

1) GRÁFICO DE 1 DIA
- Agora os pontos aparecem mesmo quando existe apenas uma data no filtro.
- Entregues, retornadas e tentativas ficam visíveis por marcadores.
- Quando Entregues e Tentativas têm o mesmo valor, os marcadores concêntricos permitem enxergar as duas séries.

2) ENTREGA QUE VOLTOU
- Ao registrar que uma entrega voltou sem concluir, o registro original continua no ciclo anterior.
- O sistema cria automaticamente uma nova tentativa ligada à anterior.
- A nova tentativa volta para "Na loja" e fica disponível para ser adicionada a outro ciclo.
- O histórico da primeira tentativa não é apagado.

3) ENTREGA GRANDE / MÚLTIPLAS VIAGENS
- No fechamento do ciclo aparece a opção "Entrega grande / carga parcial".
- Use quando uma parte da compra foi entregue e o veículo precisa voltar à loja para buscar o restante.
- O ciclo anterior fica registrado como carga parcial, sem ser contado como ocorrência de retorno sem entrega.
- Uma nova viagem é criada automaticamente e fica disponível para outro ciclo.

4) CORES E CONTRASTE
- Fundo claro -> texto escuro.
- Fundo escuro -> texto branco/claro.
- Padronização aplicada em tabelas, cards, formulários, filtros, heros e gráficos.

ARQUIVOS PARA ENVIAR AO GITHUB
- index.html
- operational-fixes-v25.js
- nilo-contrast-v25.css
- route-planner-stable-v24.js
- sw.js

Depois de publicar, feche as abas antigas e faça Ctrl+F5 uma vez.

## LEIA-ME_V28.txt

NILO ENTREGAS • V28 • TIPO DA ENTREGA VISÍVEL

CORREÇÃO PRINCIPAL
No lançamento "Registrar nova compra", o bloco "Tipo da entrega" agora faz parte dos passos do próprio formulário:
1 Identificação da compra
2 Tipo da entrega
3 Taxa cobrada no PDV
4 Quando será entregue?

No passo 2 aparecem:
- Entrega normal
- Entrega grande

Ao selecionar "Entrega grande":
- aparece "Quantas viagens estão previstas?"
- aparece o controle Viagem 1 de N, Viagem 2 de N...
- as próximas viagens são liberadas conforme a anterior for concluída como carga parcial
- cada viagem guarda saída, entrega parcial/final, retorno, duração, ciclo e observação

A opção também continua disponível na edição da entrega.

ARQUIVOS PARA ENVIAR/SUBSTITUIR NO GITHUB
1. index.html
2. sw.js
3. operational-fixes-v28.js
4. nilo-contrast-v28.css
5. route-planner-stable-v24.js

IMPORTANTE
Envie TODOS os arquivos acima. O index.html precisa apontar para operational-fixes-v28.js e nilo-contrast-v28.css.
Depois que o GitHub Pages publicar, feche a aba do sistema e abra novamente. Faça Ctrl+F5 uma vez.

A rota planejada V24 foi mantida.

## LEIA-ME_V29.txt

NILO ENTREGAS • V29 — RETORNO DISPONÍVEL PARA NOVA SAÍDA

Correção principal:
- Uma entrega que voltou sem ser entregue mantém a tentativa anterior como DEVOLVIDA.
- O sistema cria uma NOVA TENTATIVA vinculada à mesma compra, com status NA LOJA.
- Essa nova tentativa fica disponível para entrar em outro ciclo/saída.
- A tentativa anterior continua no histórico com ciclo, saída, retorno e motivo.
- Se a devolução for de hoje e já tiver sido registrada antes desta correção, a V29 faz o reparo automaticamente.
- A nova tentativa usa a data operacional atual, permitindo nova saída inclusive quando a tentativa anterior foi em outro momento.

Também preserva tudo da V28: entrega normal/grande, múltiplas viagens, contraste e rota planejada V24.

PUBLICAÇÃO:
Envie/substitua os arquivos deste ZIP na RAIZ do repositório GitHub.
Depois aguarde o GitHub Pages atualizar e faça Ctrl+F5 uma vez.

## LEIA-ME_V31.txt

NILO ENTREGAS • V31 — RELANÇAMENTO DE DEVOLVIDAS

- Mantém a tentativa devolvida no histórico.
- Ao clicar em “Montar nova saída”, cria ou reativa uma tentativa “Na loja”.
- Funciona mesmo se a devolução foi em outro dia.
- Tentativa aberta com data antiga é movida para o dia operacional atual.
- Não reabre compra já finalizada.
- Não executa reparo automático ao iniciar, evitando loop de recarregamento.

Envie os arquivos diretamente para a RAIZ do GitHub e substitua os existentes.
Depois faça Ctrl + F5 uma vez.

## LEIA-ME_V32.txt

NILO ENTREGAS • V32 — BACKUP AUTOMÁTICO

O que muda:
- Cada gravação do estado do aplicativo é detectada no IndexedDB e colocada na fila de sincronização.
- Cada envio para o Supabase gera histórico automático no banco por triggers já instalados.
- Se estiver sem internet, as alterações permanecem no aparelho e entram na fila para envio quando a conexão voltar.
- A sincronização rejeita estados remotos que reduzam a base de forma perigosa (ex.: centenas de entregas -> zero).
- O banco também possui uma proteção BEFORE UPDATE contra sobrescrita vazia.
- A tela de conexão passa a indicar "Backup automático ativo".

Arquivos para a raiz do GitHub:
- public-sync.js
- sw.js

Depois da publicação: Ctrl + F5 uma vez.

## LEIA-ME_V33_2_1.txt

NILO ENTREGAS — V33.2.1 • LAYOUT APROVADO RESTAURADO

ESTA É A VOLTA AO ÚLTIMO VISUAL APROVADO (V33/V33.2).
Não é um novo desenho.

Correções técnicas feitas sem redesenhar:
- remove a faixa lateral de 152px herdada da V32;
- menu aberto = 252px e conteúdo começa imediatamente ao lado;
- menu recolhido = 76px e conteúdo começa imediatamente ao lado;
- barra superior acompanha a largura útil;
- Triela correta enviada pelo usuário;
- mascote de corpo inteiro limpo, na ordem Triela -> mascote -> status;
- favicon/PWA com mascote de corpo inteiro;
- remove conflito visual V34;
- mantém public-sync V32.1, V31 operacional e V24 de rotas.

SUBSTITUIR NA RAIZ DO GITHUB:
index.html
public-sync.js
nilo-approved-v33.js
sw.js
manifest.webmanifest
favicon-v33.png

SUBSTITUIR A PASTA icons:
icons/icon-192.png
icons/icon-512.png

Os arquivos V34 podem permanecer no repositório, mas o index desta versão NÃO os carrega.

## LEIA-ME_V33_3.txt

NILO ENTREGAS — V33.3.0 • VISUAL APROVADO EXATO

ESTA VERSÃO USA COMO FONTE DE VERDADE O PACOTE VISUAL APROVADO:
- Central de Operação
- Entregas & Programadas
- Registrar nova compra
- Ciclos & Rotas
- Quilometragem & Frota
- Análises & Relatórios
- Administração & Cadastros
- Mobile Central
- Mobile Registrar compra

MELHORIAS POSTERIORES TAMBÉM INCORPORADAS:
- app ocupa 100% da largura útil;
- menu recolhido não deixa faixa branca;
- barra superior acompanha o menu aberto/recolhido;
- menu aberto: Triela correta > mascote corpo inteiro > status;
- menu recolhido: NILO + Triela aparecem no topo;
- favicon/ícone usa mascote de corpo inteiro;
- mobile segue o padrão aprovado;
- nenhuma funcionalidade operacional é removida.

NÃO ALTERA:
- app.js;
- public-sync.js / Supabase / backup automático;
- operational-fixes-v31.js;
- route-planner-stable-v24.js;
- dados já cadastrados.

ARQUIVOS A SUBSTITUIR/ADICIONAR NA RAIZ DO GITHUB:
1. index.html
2. sw.js
3. manifest.webmanifest
4. nilo-approved-v33.js
5. nilo-approved-v33-exact.css
6. logo-nilo-aprovada.png
7. logo-triela-aprovada.png
8. mascote-nilo-aprovado.png
9. favicon-v33.png
10. pasta icons/ (icon-192.png e icon-512.png)

Depois do GitHub Pages atualizar, faça Ctrl + F5 uma única vez.

## LEIA-ME_V33_4.txt

NILO ENTREGAS — V33.4 TELAS APROVADAS EXATAS

Esta atualização implementa a composição visual aprovada EM CADA TELA:
- Central de Operação
- Entregas & Programadas
- Registrar nova compra
- Ciclos & Rotas
- Quilometragem & Frota
- Análises & Relatórios
- Administração & Cadastros
- Mobile Central
- Mobile Registrar compra

IMPORTANTE:
- os números mostrados são lidos dos dados reais do sistema;
- a camada nova é somente de apresentação e NÃO grava no banco;
- app.js permanece V14.8;
- public-sync permanece V32.1;
- operacional V31 permanece;
- rotas V24 permanecem;
- Triela, mascote, favicon, tela cheia e menu recolhido permanecem conforme os ajustes aprovados depois.

Envie TODO o conteúdo para a raiz do GitHub, mantendo a pasta icons.

## LEIA-ME_V33_5.txt

NILO ENTREGAS — V33.5 FINAL APROVADA

ESTA É A ATUALIZAÇÃO DO SISTEMA REAL, BASEADA NA SIMULAÇÃO APROVADA.

Inclui:
- layout visual V33 aprovado em todas as abas;
- Central de Operação;
- Entregas & Programadas;
- Registrar nova compra;
- Ciclos & Rotas;
- Quilometragem & Frota;
- Análises & Relatórios;
- Administração & Cadastros;
- mobile;
- identificação da compra sem duplicidade:
  Nº da compra, cupom, DOC, caixa, data e hora;
- endereço/cliente em bloco separado;
- prioridade mantida na etapa de entrega;
- ilustrações realistas aprovadas na frota;
- botões de frota alinhados no rodapé dos cards.

NÃO ALTERA:
- app.js;
- public-sync.js;
- Supabase;
- dados existentes;
- backup automático;
- operational-fixes-v31.js;
- route-planner-stable-v24.js.

COMO ATUALIZAR:
Extraia o ZIP e envie TODO o conteúdo para a raiz do repositório,
mantendo a pasta icons e substituindo os arquivos quando solicitado.

Depois aguarde o GitHub Pages atualizar e faça Ctrl+F5 uma vez.

## LEIA-ME_V33_6.txt

NILO ENTREGAS — V33.6 FUNÇÕES COMPLETAS + VISUAL ATUAL

Objetivo:
Manter o visual V33 aprovado e recuperar o acesso a todas as funcionalidades do sistema anterior.

Recuperado / reconectado:
- Encerrar e reabrir operação do dia;
- checkpoint e tela operacional completa;
- registrar, editar e consultar custos;
- categorias de custos;
- Programadas / Reagendadas completas;
- Central de Pendências completa;
- Pesquisa completa de entregas;
- histórico completo de entregas e ações;
- montar nova saída;
- detectar / reutilizar saídas;
- editar, gerenciar e fechar ciclos;
- roteiro planejado;
- histórico REAL de rotas/GPS por período;
- abrir rotas no Google Maps;
- abrir / fechar / editar KM por veículo;
- controle completo de quilometragem;
- dashboard completo;
- relatórios completos;
- análise por bairro;
- lixeira com restaurar / excluir / esvaziar;
- cadastros completos: veículos, bairros, colaboradores, categorias de custo, motivos, regras e dados;
- ambiente de treinamento.

Estratégia:
As telas aprovadas continuam como VISÃO ATUAL.
As telas completas do app original ficam acessíveis por uma barra "FUNÇÕES COMPLETAS",
com o mesmo tema azul-marinho / branco / amarelo.

Segurança:
- NÃO substitui app.js
- NÃO substitui operational-fixes-v31.js
- NÃO substitui route-planner-stable-v24.js
- NÃO altera a estrutura do Supabase
- NÃO apaga dados

## LEIA-ME_V34_FINAL.txt

NILO ENTREGAS — V34.0 FINAL APROVADA

Implementação baseada nas artes finais aprovadas.

Preserva:
- app.js 14.8.0
- operational-fixes-v31.js
- route-planner-stable-v24.js
- public-sync.js V32.1
- Supabase e dados existentes
- relatórios prontos atuais

Melhora:
- mesma identidade visual aprovada em todas as abas
- Central com montar novo ciclo, encerrar ciclo e registrar chegada
- marco separado Chegada ao cliente
- filtros por período livre
- Entregas/Programadas com pesquisa avançada
- Ciclos/Rotas com ações integradas
- KM/Frota com cards aprovados e botões reais
- Análises com filtros por período e gráficos profissionais
- relatório pronto atual mantido
- novo montador de relatório personalizado
- Administração completa, backup, treinamento e lixeira
- mobile responsivo

## LEIA-ME_V35.txt

NILO ENTREGAS — V35.0 ARTES APROVADAS EXATAS

Objetivo:
Reproduzir a identidade e a composição das artes finais aprovadas, mantendo e melhorando todas as funções.

Principais correções:
- menu lateral simplificado e alinhado às artes;
- Central sem título duplicado dentro do conteúdo;
- mapa da Central no mesmo padrão visual da arte;
- Novo ciclo e Encerrar ciclo acessíveis na própria Central;
- Chegada ao cliente mantida como marco separado;
- Entregas & Programadas no padrão aprovado;
- Ciclos & Rotas com Levadas / Entregues / Voltaram / Tempo;
- resumo de devolvidas completo;
- KM/Frota preservado com imagens e botões funcionais;
- Análises com filtro por Dia/Semana/Mês/Personalizado + Entregador + Bairro;
- relatório pronto atual mantido + relatório personalizado adicional;
- Administração reorganizada no mesmo padrão visual das artes;
- mobile preservado.

Não substitui app.js, V31, V24 ou public-sync.

## LEIA_PRIMEIRO.txt

NILO ENTREGAS — HOTFIX V33.1 ANTI-TRAVAMENTO

Motivo: a V33 observava toda a árvore do aplicativo com MutationObserver. O próprio código visual alterava o DOM dentro do observer, disparando novas observações em sequência e podendo travar o Chrome na tela de carregamento.

SUBSTITUA NA RAIZ DO GITHUB:
1. index.html
2. nilo-approved-v33.js
3. sw.js

NÃO ALTERE:
- app.js
- public-sync.js
- operational-fixes-v31.js
- route-planner-stable-v24.js
- banco/Supabase

Depois de publicar, feche as abas travadas, abra o site novamente e faça Ctrl+F5 UMA vez.

## LEIA_PRIMEIRO_V33.txt

NILO ENTREGAS — V33 VISUAL APROVADA
===================================

ESTA ATUALIZAÇÃO É VISUAL/ORGANIZACIONAL.
Ela NÃO substitui app.js, NÃO substitui public-sync.js e NÃO substitui operational-fixes-v31.js.

O QUE ENTRA NA V33
- Novo padrão visual navy/azul + amarelo + branco.
- Ícones do menu no padrão aprovado.
- Menu organizado por OPERAÇÃO, ANÁLISES, ADMINISTRAÇÃO e TREINAMENTO.
- Funções parecidas agrupadas visualmente, sem excluir nenhum botão original.
- Menu aberto: Triela fica no bloco inferior do menu e o mascote aparece no menu.
- Menu recolhido: NILO + Triela continuam no topo.
- Área interna das abas recebe o mesmo padrão visual, com variações leves de cor.
- Registrar compra continua acessível no topo, na operação e por atalho no mobile.
- Modal de Registrar nova compra recebe novo visual e passo a passo, preservando todos os campos e handlers atuais.
- Mobile recebe navegação inferior: Início, Entregas, Rotas, Relatórios e Mais + atalho Registrar compra.

FUNCIONALIDADES PRESERVADAS
- Entregas e programadas
- Entrega normal e entrega grande / múltiplas viagens
- Ciclos, retornos e relançamento de devolvidas
- Rotas e histórico de rotas
- Quilometragem
- Custos, análises e relatórios
- Cadastros, lixeira e treinamento
- Backup automático V32 e sincronização Supabase

PARA ATUALIZAR NO GITHUB
Substitua SOMENTE:
1. index.html
2. sw.js
3. nilo-approved-v33.js

NÃO substitua app.js, public-sync.js, operational-fixes-v31.js ou o banco.
Depois aguarde o GitHub Pages atualizar e faça Ctrl+F5 uma vez.
